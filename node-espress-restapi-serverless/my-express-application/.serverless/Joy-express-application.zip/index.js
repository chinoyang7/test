// index.js

const serverless = require("serverless-http");
const express = require("express");
const app = express();

// Routes
app.get("/", function(req, res) {
  res.send("Hello World!");
});

// Listen
const port = process.env.PORT || 3000;
app.listen(port);
console.log("Listening on localhost:" + port);

module.exports.handler = serverless(app);
